import React from 'react';

const latestValue = (props) => {

	return (
		<div>
			<p>Tipo de cambio al día de hoy: {props.tipoDeCambio}</p>
		</div>	
		);
};



export default latestValue;